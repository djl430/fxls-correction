/* Offline ZIP (stored PNG entries, UTF-8 names). No network dependency. */
(function(root){
  const table=Array.from({length:256},(_,n)=>{for(let i=0;i<8;i++)n=n&1?0xedb88320^(n>>>1):n>>>1;return n>>>0});
  function crc32(bytes){let crc=0xffffffff;for(const b of bytes)crc=table[(crc^b)&255]^(crc>>>8);return (crc^0xffffffff)>>>0}
  async function zipEntries(entries){
    if(entries.length>65535)throw new Error('文件数量超出 ZIP 限制');
    const files=[],directory=[];let offset=0,centralSize=0;
    for(const entry of entries){
      const name=new TextEncoder().encode(entry.name),data=new Uint8Array(await entry.blob.arrayBuffer()),crc=crc32(data);
      if(name.length>65535||offset+data.length+name.length+30>0xffffffff)throw new Error('文件超出 ZIP 大小限制');
      const local=new Uint8Array(30),lv=new DataView(local.buffer);
      lv.setUint32(0,0x04034b50,true);lv.setUint16(4,20,true);lv.setUint16(6,0x800,true);lv.setUint16(12,33,true);
      lv.setUint32(14,crc,true);lv.setUint32(18,data.length,true);lv.setUint32(22,data.length,true);lv.setUint16(26,name.length,true);
      const central=new Uint8Array(46),cv=new DataView(central.buffer);
      cv.setUint32(0,0x02014b50,true);cv.setUint16(4,20,true);cv.setUint16(6,20,true);cv.setUint16(8,0x800,true);cv.setUint16(14,33,true);
      cv.setUint32(16,crc,true);cv.setUint32(20,data.length,true);cv.setUint32(24,data.length,true);cv.setUint16(28,name.length,true);cv.setUint32(42,offset,true);
      files.push(local,name,data);directory.push(central,name);offset+=30+name.length+data.length;centralSize+=46+name.length;
    }
    if(offset+centralSize>0xffffffff)throw new Error('文件超出 ZIP 大小限制');
    const end=new Uint8Array(22),ev=new DataView(end.buffer);ev.setUint32(0,0x06054b50,true);ev.setUint16(8,entries.length,true);ev.setUint16(10,entries.length,true);ev.setUint32(12,centralSize,true);ev.setUint32(16,offset,true);
    return new Blob([...files,...directory,end],{type:'application/zip'});
  }
  root.ReviewExport={zipEntries};if(typeof module!=='undefined')module.exports=root.ReviewExport;
})(typeof globalThis!=='undefined'?globalThis:this);
