/* Presentation only: never changes question grouping or grading facts. */
(function(root){
  function overviewMetrics(submission,students,pending,review,correctRate=null){
    const count=submission.rosterProvided?`${submission.submittedStudentCount||0}/${submission.rosterStudentCount||0}`:students;
    return [[count,'提交作业数'],[pending,'待批改作答数'],[review,'推荐复核作答数'],[Number.isFinite(correctRate)?correctRate.toFixed(1)+'%':'暂无','班级平均正确率']];
  }
  function cropRegion(width,height,r,pad=0){
    if(!r||![width,height,r.x,r.y,r.width,r.height,pad].every(Number.isFinite)||width<=0||height<=0||r.width<=0||r.height<=0)return null;
    const x=Math.max(0,Math.floor(r.x-pad)),y=Math.max(0,Math.floor(r.y-pad));
    const right=Math.min(width,Math.ceil(r.x+r.width+pad)),bottom=Math.min(height,Math.ceil(r.y+r.height+pad));
    return right>x&&bottom>y?{x,y,width:right-x,height:bottom-y}:null;
  }
  function markSize(status){return status==='PASS'||status==='HALF_PASS'?48:38}
  function annotationLayout(width,height,units){
    const entries=units.map(u=>({unit:u,region:cropRegion(width,height,u.region||u.questionRegion)})).filter(e=>e.region);
    const marks=[],baseSize=48,gap=Math.max(4,width/300);
    const overlaps=(a,b)=>a.x<b.x+b.width&&a.x+a.width>b.x&&a.y<b.y+b.height&&a.y+a.height>b.y;
    let outputWidth=width,outputHeight=height;
    for(const {unit,region:r} of entries){
      const size=markSize(unit.finalStatus||unit.originalStatus);
      // Keep a status-independent 48px anchor slot so changing PASS/FAILED never moves the mark.
      const cy=Math.min(height-baseSize/2,Math.max(baseSize/2,r.y+r.height/2));
      const slotY=cy-baseSize/2,rightX=r.x+r.width+gap,leftX=r.x-baseSize-gap;
      const rightFits=rightX+baseSize<=width,leftFits=leftX>=0;
      const side=rightFits?'right':leftFits?'left':'gutter';
      let slot={x:side==='right'?rightX:side==='left'?leftX:width+gap,y:slotY,width:baseSize,height:baseSize};
      // Other answer rectangles are not obstacles: using them here detached marks from their own answers.
      // Only separate actual mark slots, always outward on the chosen side and on the same answer row.
      const occupied=marks.map(m=>({x:m.slotX,y:m.slotY,width:baseSize,height:baseSize}));
      const conflicts=p=>occupied.some(b=>overlaps(p,b)&&Math.abs((p.y+p.height/2)-(b.y+b.height/2))<baseSize/2);
      const step=baseSize+2*gap;
      if(side==='right')while(conflicts(slot)&&slot.x+baseSize+step<=width)slot.x+=step;
      if(side==='left')while(conflicts(slot)&&slot.x-step>=0)slot.x-=step;
      let gutter=false;
      if(side==='gutter'||conflicts(slot)){
        gutter=true;slot={x:width+gap,y:slotY,width:baseSize,height:baseSize};
        while(conflicts(slot))slot.x+=step;
        outputWidth=Math.max(outputWidth,slot.x+baseSize+gap);outputHeight=Math.max(outputHeight,slot.y+baseSize+gap);
      }
      const inset=(baseSize-size)/2;
      marks.push({unitId:unit.unitId,x:slot.x+inset,y:slot.y+inset,size,gutter,slotX:slot.x,slotY:slot.y});
    }
    return {width:outputWidth,height:outputHeight,marks};
  }
  function unitsAtPoint(x,y,units){
    const hit=r=>r&&[r.x,r.y,r.width,r.height].every(Number.isFinite)&&r.width>0&&r.height>0&&x>=r.x&&x<=r.x+r.width&&y>=r.y&&y<=r.y+r.height;
    const answers=units.filter(u=>hit(u.region));
    return answers.length?answers:units.filter(u=>hit(u.questionRegion));
  }
  function answerPreviewSize(crop,pageWidth){
    // A common page-relative scale, independent of answer length/card width.
    const scale=Math.min(1,1100/(Number.isFinite(pageWidth)&&pageWidth>0?pageWidth:1700));
    return {width:crop.width*scale,height:crop.height*scale,scale};
  }
  root.ReviewLayout={overviewMetrics,annotationLayout,cropRegion,unitsAtPoint,answerPreviewSize,markSize};
  if(typeof module!=='undefined')module.exports=root.ReviewLayout;
})(typeof globalThis!=='undefined'?globalThis:this);
