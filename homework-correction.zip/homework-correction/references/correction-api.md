# 整页批改接口

## 版本

三个接口均为 `POST application/json`，请求与响应结构相同：

| 版本 | 地址 | 使用建议 |
|---|---|---|
| Base | `https://metis-aione.zhenguanyu.com/metis-ai-model/api/inner/general-page-correction/base` | 速度优先 |
| Pro | `https://metis-aione.zhenguanyu.com/metis-ai-model/api/inner/general-page-correction/pro` | 默认，兼顾效果和速度 |
| Max | `https://metis-aione.zhenguanyu.com/metis-ai-model/api/inner/general-page-correction/max` | 效果优先、允许更长等待 |

不要发送 `strategy`，也不要因一个版本超时而把同一请求并行发送给其他版本。

## 请求

```json
{
  "queryId": "task-id-image-hash",
  "imageBase64": "base64-content"
}
```

- `queryId` 必填；同一图片重试复用同一值。
- `imageBase64` 是图片内容，不是 URL，不带 Data URL 前缀。
- 日志不得记录完整 Base64。
- 本接口不直接接受 PDF、压缩包、目录、名册、评分细则或“忽略旧批注”参数。输入转换与分流在调用前完成，详见 [输入识别与编排](input-orchestration.md)。

## 响应

成功响应包含 `queryId` 和 `resultList`。题目与 `subResultList` 元素共享结构：

- `region`：原图像素坐标 `{x,y,width,height}`；
- `content`：识别题干；
- `correctionStatus`：综合状态；
- `correctionReason`：存在时展示，不自行补充；
- `answerList`：直属答案区域；
- `subResultList`：递归小题。

答案元素包含 `region`、`content`、`correctionStatus` 和可选 `correctionReason`。所有字段都可能缺失；字段缺失不是 `FAILED`。

现有响应契约未约定每题满分、实得分或总分，不能从 `HALF_PASS` 推出得一半分。已批改卷面中的旧对错符号/手写得分不得转换为本次接口状态；接口没有忽略旧批注开关，重新调用不构成无批注干扰的保证。

## 状态

| 接口状态 | 对外文案 |
|---|---|
| `PASS` | 正确 |
| `HALF_PASS` | 半对 |
| `FAILED` | 错误 |
| `UNDONE` | 未作答，初始判为错误 |
| `UNABLE_TO_CHECK` | 暂无法批改 |
| `UNSUPPORTED` | 暂不支持 |
| `UNKNOWN` 或缺失 | 状态未知 |

`UNDONE` 保留为接口原始状态，但生成 ReviewUnit 时将有效 `finalStatus` 设为 `FAILED`，计入错误并使用错误批改符号。`UNABLE_TO_CHECK`、`UNSUPPORTED`、`UNKNOWN` 和缺失状态仍属于未完成，不得展示为学生错误。

## 异常

- HTTP 400：参数错误，不自动重试。
- HTTP 500 或网络超时：有限次数退避重试。
- 空 `resultList`：页面无可展示结果，提示检查图片清晰度和完整性。
- 失败提示只说明现象、影响范围和下一步，不暴露堆栈、接口地址或内部模型信息。

图片展示缩放时，题框和答案框按显示尺寸与原图尺寸同比例缩放。
