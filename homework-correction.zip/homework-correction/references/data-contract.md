# 批改任务数据契约

## 输入文件

图片、PDF、归档和目录先按 [输入识别与编排](input-orchestration.md) 处理为单份作业的页图片；参考材料、重复页与待归属材料不得直接混入学生作答统计。输入清单用于记录原始来源、派生页与分组证据，当前脚本不直接解析该清单。

### 学生名册

CSV 使用以下表头：

```csv
file_name,student_name,student_id,page_number
张三-第1页.jpg,张三,s-001,1
,李四,s-002,
```

也可传相同字段的 JSON 数组。`file_name` 可为空，用于保留尚未提交作业的学生；同一学生多页可以出现多行，但 `student_id` 应保持一致。学生关系优先使用上游 ID，其次使用名册的确定匹配；不能确定时使用稳定临时编号。

只有完整且适用于本份作业的名册传入 `--roster`；部分名单仅用于识别学生。文本/表格/PDF/图片名册先读取并规范化，重名不同人保留不同 ID。脚本的 `file_name` 映射使用文件基本名，多目录同名时不要使用该映射：名册保留空 `file_name` 行，图片身份通过 `--page-order` 的绝对路径关联。稳定临时学生编号只用于已确认同一学生的提交，归属不明的散页不能一图一人计数。

### 答案解析

答案 JSON 以 `questionKey` 为键：

```json
{
  "question-abc": {
    "answer": "参考答案",
    "analysis": "解析"
  }
}
```

答案只用于辅助复核。现有整页接口不接受答案参数，没有重批适配器时不得宣称修改答案会影响批改。

### 页序清单

多页任务使用独立的 `--page-order` JSON 清单，字段与识别流程见 [页序整理](page-order.md)。Page 保留送批图片的 `sourcePath`、`uploadIndex` 和 `pageOrderEvidence`；转换前的原始文件与PDF页索引另存输入清单。`pageNumber` 表示确认的逻辑页序，关联 QuestionOccurrence、ReviewUnit 和 QuestionGroup 的页码必须同步。上传索引只用于追溯，展示、同题合并和下载以逻辑页序为准。缺页不压缩编号，排序不修改 `pageId`、`unitId` 或学生改判历史。

## 任务层级

```text
CorrectionTask
├── StudentSubmission
│   └── Page
│       └── QuestionOccurrence
│           └── ReviewUnit
├── QuestionGroup
├── ReviewQueue
└── Statistics
```

`ReviewUnit` 是统计和改判的最小单元：优先使用答案；无直属答案时递归子题；无答案也无子题时使用题目本身。父题综合状态不重复计数。

每条单元保留 `unitId`、`questionKey`、任务/学生/图片关联、题目路径、内容、区域、原因、`originalStatus`、`finalStatus` 和 `history`。

## 同题合并

先确定同一作业/卷型、共同逻辑页与可靠学生归属，再执行下述对齐。不同作业拆成独立 CorrectionTask，即使标题或题号相同也不得混合。

优先使用上游题目 ID。否则先综合页面序号、递归路径、规范化题干和位置生成页内 `questionKey`，再按“相同任务页 + 相同层级深度 + 相近版面位置”对齐不同学生的同一道印刷题。不得只按 API 返回顺序或题号合并；无法可靠对齐时保持单页题目，冲突时暂停受影响统计。多页作业的复核导航应同时显示页码和题目路径，例如“第 2 页 · 第 4 题”，避免各页题号重置造成歧义。

## 统计

统计只覆盖本任务已纳入的有效材料；未提交学生、未上传页和无法识别的缺失区域不补造成作答，不计为错误。已确认材料但接口失败与“尚未提交”分开说明。试卷每题印刷满分不改变下面的正确率定义；当前数据模型无可靠得分计算，分值证据留在输入清单，不能把半对折半或把正确率当得分率。

```text
全部作答数 = ReviewUnit 数量
已完成批改数 = 正确 + 半对 + 错误
错误数 = FAILED + 原始状态为 UNDONE 且未被老师改判的作答
未完成批改数 = 暂无法批改 + 暂不支持 + 状态未知
班级正确率 = 全部正确数 ÷ 全部作答数 × 100%
单题正确率 = 该题正确数 ÷ 该题全部作答数 × 100%
单个学生正确率 = 该学生正确数 ÷ 该学生全部作答数 × 100%
```

- 保留 1 位小数；半对不折算为正确。
- 分母为 0 时显示“暂无数据”。
- 图片请求失败、重复和空结果另行统计。
- 所有视图从同一组 `finalStatus` 计算；初始值等于 `originalStatus`。
- `UNDONE` 是例外：保留 `originalStatus=UNDONE`，初始 `finalStatus=FAILED`。旧任务或旧本地状态中的 `UNDONE` 在读取时同样规范为 `FAILED`；老师后续改判仍以最新合法状态为准。
- 每次改判自动刷新上述三类正确率，无需确认。相同文本作答结果不一致保留复核提示，但不暂停按有效状态计算；关系确实不可靠时仍不得强行合并统计。
- 改判历史保留前值、后值、时间和操作来源。

## 提交率

只有任务传入花名册时生成 `submissionStats`；页面在“提交作业数”中展示人数比，不再单独展示百分比卡片：

```text
已提交学生数 = 作业图片关联到花名册的 studentId 去重数
花名册全部学生数 = 花名册 studentId 去重数
提交率 = 已提交学生数 ÷ 花名册全部学生数 × 100%
```

同一学生提交多页只计 1 人；未匹配到花名册的临时学生不计入已提交学生数。花名册人数为 0 时提交率显示“暂无”，不能显示 0%。

## 结构化结果

任务目录中的 `task.json` 是 AI 批改的只读基线，保留完整任务关系、原始状态、复核队列和初始统计，图片通过相对路径关联且不嵌入 Base64。复核页渲染或老师改判不得覆盖该文件。

桌面端可编辑复核页把老师改判原子写入同目录 `review-state.json`。文件最小契约为：

```json
{
  "schemaVersion": "1.0",
  "taskId": "与 task.json 相同",
  "revision": 3,
  "updatedAt": "2026-09-09T08:00:00+00:00",
  "units": {
    "unit-id": {
      "finalStatus": "FAILED",
      "history": [
        {
          "from": "PASS",
          "to": "FAILED",
          "changedAt": "2026-09-09T08:00:00.000Z",
          "source": "cycle"
        }
      ]
    }
  }
}
```

- `revision` 从 0 开始，仅由本机复核服务成功写盘后递增；PUT 必须携带最后确认的 `baseRevision`，版本不一致返回冲突，不能覆盖较新文件。
- `units` 只保存老师已改判的 `unitId`、合法 `finalStatus` 与历史；未改判单元继续读取 `task.json`。合并优先级为 `review-state.json` 合法改判 > `task.json.finalStatus` > `task.json.originalStatus`，最后按规则将有效 `UNDONE` 规范为 `FAILED`。
- 每次写入使用同目录临时文件、flush、fsync 和原子替换，避免 Agent 读到半个 JSON。页面只在服务确认后显示“已同步到本地文件”。
- 浏览器 localStorage 只保存同一份改判快照、已确认版本与脏标记，作为服务不可用时的待同步备份；它不是 Agent 的数据源。
- Agent 只在老师明确要求读取最新结果或明确触发下游动作时，通过 `scripts/read_latest_result.py` 验证并合并两份文件、重新计算班级/题目/学生统计。不得解析 `review.html` DOM 或把静态 Markdown 当数据源。
- `task.json`、`review-state.json` 均属于 Skill 内部文件，默认不在面向老师的最终回复中展示或提供入口；只有用户明确要求查看、调试或导出结构化数据时才按指定范围提供。

复核页不提供 JSON/CSV 手工导出按钮。下载批改图时将当前有效状态对应的符号绘制到副本，不修改原图。
