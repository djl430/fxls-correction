#!/usr/bin/env python3
"""Build a resumable homework-correction task from page images."""

from __future__ import annotations

import argparse
import base64
import csv
import hashlib
import json
import math
import re
import shutil
import sys
import time
import unicodedata
import urllib.error
import urllib.request
import uuid
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Iterable


ENDPOINTS = {
    "base": "https://metis-aione.zhenguanyu.com/metis-ai-model/api/inner/general-page-correction/base",
    "pro": "https://metis-aione.zhenguanyu.com/metis-ai-model/api/inner/general-page-correction/pro",
    "max": "https://metis-aione.zhenguanyu.com/metis-ai-model/api/inner/general-page-correction/max",
}

VALID_STATUSES = {"PASS", "HALF_PASS", "FAILED"}
KNOWN_STATUSES = VALID_STATUSES | {
    "UNDONE",
    "UNABLE_TO_CHECK",
    "UNSUPPORTED",
    "UNKNOWN",
}
STATUS_LABELS = {
    "PASS": "正确",
    "HALF_PASS": "半对",
    "FAILED": "错误",
    "UNDONE": "未作答",
    "UNABLE_TO_CHECK": "暂无法批改",
    "UNSUPPORTED": "暂不支持",
    "UNKNOWN": "状态未知",
}
SUGGESTED_SIGNALS = (
    "证明",
    "写出过程",
    "说明理由",
    "简答",
    "作文",
    "开放题",
    "阅读理解",
    "解答过程",
    "多种方法",
    "一题多解",
)


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def normalize_text(value: Any) -> str:
    text = unicodedata.normalize("NFKC", str(value or ""))
    return re.sub(r"\s+", "", text).strip().lower()


def normalize_status(value: Any) -> str:
    status = str(value or "UNKNOWN").upper()
    return status if status in KNOWN_STATUSES else "UNKNOWN"


def judged_status(value: Any) -> str:
    """Return the effective grading status while preserving source status elsewhere."""
    status = normalize_status(value)
    return "FAILED" if status == "UNDONE" else status


def normalize_region(value: Any) -> dict[str, float] | None:
    if not isinstance(value, dict):
        return None
    try:
        return {
            "x": float(value.get("x", 0)),
            "y": float(value.get("y", 0)),
            "width": float(value.get("width", 0)),
            "height": float(value.get("height", 0)),
        }
    except (TypeError, ValueError):
        return None


def _short_hash(payload: Any, prefix: str) -> str:
    encoded = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return f"{prefix}-{hashlib.sha256(encoded).hexdigest()[:16]}"


def question_key(
    page_number: int,
    path: list[int],
    content: str,
    region: dict[str, Any] | None,
) -> str:
    normalized = normalize_region(region) or {"x": 0, "y": 0, "width": 0, "height": 0}
    coarse_region = {key: round(value / 50) for key, value in normalized.items()}
    return _short_hash(
        {
            "pageNumber": int(page_number or 1),
            "path": [int(item) for item in path],
            "content": normalize_text(content),
            "region": coarse_region,
        },
        "question",
    )


def _unit_id(task_id: str, page_id: str, path: list[int], answer_index: int, content: str) -> str:
    return _short_hash(
        {
            "taskId": task_id,
            "pageId": page_id,
            "path": path,
            "answerIndex": answer_index,
            "content": normalize_text(content),
        },
        "unit",
    )


def normalize_page(response: dict[str, Any], page: dict[str, Any], task_id: str) -> dict[str, Any]:
    """Normalize a page response without double-counting parent question states."""
    occurrences: list[dict[str, Any]] = []
    units: list[dict[str, Any]] = []
    page_number = int(page.get("pageNumber") or 1)
    page_id = str(page["pageId"])

    def walk(node: dict[str, Any], path: list[int]) -> None:
        content = str(node.get("content") or "")
        region = normalize_region(node.get("region"))
        key = question_key(page_number, path, content, region)
        occurrence_id = _short_hash({"pageId": page_id, "path": path, "questionKey": key}, "occurrence")
        occurrence = {
            "occurrenceId": occurrence_id,
            "questionKey": key,
            "pageId": page_id,
            "pageNumber": page_number,
            "studentId": page.get("studentId"),
            "path": path,
            "pathLabel": ".".join(str(item) for item in path),
            "content": content,
            "region": region,
            "originalStatus": normalize_status(node.get("correctionStatus")),
            "correctionReason": str(node.get("correctionReason") or ""),
            "unitIds": [],
        }

        answers = node.get("answerList") if isinstance(node.get("answerList"), list) else []
        children = node.get("subResultList") if isinstance(node.get("subResultList"), list) else []
        occurrence["hasChildren"] = bool(children)
        occurrences.append(occurrence)

        if answers:
            for answer_index, answer in enumerate(answers, start=1):
                if not isinstance(answer, dict):
                    continue
                answer_content = str(answer.get("content") or "")
                unit_id = _unit_id(task_id, page_id, path, answer_index, answer_content)
                status = normalize_status(answer.get("correctionStatus"))
                unit = {
                    "unitId": unit_id,
                    "taskId": task_id,
                    "questionKey": key,
                    "pageId": page_id,
                    "pageNumber": page_number,
                    "studentId": page.get("studentId"),
                    "studentName": page.get("studentName"),
                    "sourceName": page.get("sourceName"),
                    "path": path,
                    "pathLabel": occurrence["pathLabel"],
                    "answerIndex": answer_index,
                    "content": answer_content,
                    "originalStatus": status,
                    "finalStatus": judged_status(status),
                    "correctionReason": str(answer.get("correctionReason") or node.get("correctionReason") or ""),
                    "region": normalize_region(answer.get("region")),
                    "questionRegion": region,
                    "history": [],
                }
                units.append(unit)
                occurrence["unitIds"].append(unit_id)
        elif not children:
            unit_id = _unit_id(task_id, page_id, path, 0, content)
            status = normalize_status(node.get("correctionStatus"))
            unit = {
                "unitId": unit_id,
                "taskId": task_id,
                "questionKey": key,
                "pageId": page_id,
                "pageNumber": page_number,
                "studentId": page.get("studentId"),
                "studentName": page.get("studentName"),
                "sourceName": page.get("sourceName"),
                "path": path,
                "pathLabel": occurrence["pathLabel"],
                "answerIndex": 0,
                "content": content,
                "originalStatus": status,
                "finalStatus": judged_status(status),
                "correctionReason": str(node.get("correctionReason") or ""),
                "region": region,
                "questionRegion": region,
                "history": [],
            }
            units.append(unit)
            occurrence["unitIds"].append(unit_id)

        for child_index, child in enumerate(children, start=1):
            if isinstance(child, dict):
                walk(child, path + [child_index])

    results = response.get("resultList") if isinstance(response.get("resultList"), list) else []
    for question_index, question in enumerate(results, start=1):
        if isinstance(question, dict):
            walk(question, [question_index])

    return {"questionOccurrences": occurrences, "reviewUnits": units}


def compute_stats(units: Iterable[dict[str, Any]]) -> dict[str, Any]:
    statuses = [judged_status(unit.get("finalStatus", unit.get("originalStatus"))) for unit in units]
    counts = Counter(statuses)
    total = len(statuses)
    completed = sum(counts[status] for status in VALID_STATUSES)
    return {
        "total": total,
        "completed": completed,
        "unfinished": total - completed,
        "correct": counts["PASS"],
        "halfCorrect": counts["HALF_PASS"],
        "incorrect": counts["FAILED"],
        "undone": counts["UNDONE"],
        "unableToCheck": counts["UNABLE_TO_CHECK"],
        "unsupported": counts["UNSUPPORTED"],
        "unknown": counts["UNKNOWN"],
        "correctRate": round(counts["PASS"] / total * 100, 1) if total else None,
        "completionRate": round(completed / total * 100, 1) if total else None,
    }


def apply_review_rules(question: dict[str, Any]) -> dict[str, Any]:
    units = list(question.get("units") or [])
    statuses = [judged_status(unit.get("originalStatus")) for unit in units]
    reasons: list[str] = []
    if not units:
        reasons.append("整道题没有形成有效批改结果")
    for status in statuses:
        if status not in VALID_STATUSES:
            reason = STATUS_LABELS[status]
            if reason not in reasons:
                reasons.append(reason)
    answer_statuses: dict[str, set[str]] = defaultdict(set)
    for unit, status in zip(units, statuses):
        normalized_answer = normalize_text(unit.get("content"))
        if normalized_answer:
            answer_statuses[normalized_answer].add(status)
    if any(len(values) > 1 for values in answer_statuses.values()):
        reasons.append("完全相同作答存在不同批改结果")
    if reasons:
        return {"reviewType": "mandatory", "reviewReasons": reasons}

    content = normalize_text(question.get("content"))
    matched = [signal for signal in SUGGESTED_SIGNALS if normalize_text(signal) in content]
    if matched:
        return {"reviewType": "suggested", "reviewReasons": [f"题干包含复杂作答信号：{matched[0]}"]}
    return {"reviewType": "none", "reviewReasons": []}


def group_identical_answers(questions: Iterable[dict[str, Any]]) -> list[dict[str, Any]]:
    groups: list[dict[str, Any]] = []
    for question in questions:
        buckets: dict[str, list[str]] = defaultdict(list)
        for unit in question.get("units") or []:
            normalized = normalize_text(unit.get("content"))
            if normalized:
                buckets[normalized].append(str(unit["unitId"]))
        for normalized, unit_ids in buckets.items():
            if len(unit_ids) > 1:
                groups.append(
                    {
                        "groupId": _short_hash(
                            {"questionKey": question["questionKey"], "content": normalized},
                            "identical",
                        ),
                        "questionKey": question["questionKey"],
                        "normalizedContent": normalized,
                        "unitIds": unit_ids,
                    }
                )
    return groups


def group_questions(
    occurrences: Iterable[dict[str, Any]],
    units: Iterable[dict[str, Any]],
) -> list[dict[str, Any]]:
    occurrences = list(occurrences)
    page_numbers = {
        int(occurrence.get("pageNumber") or 1)
        for occurrence in occurrences
    }
    show_page_number = len(page_numbers) > 1
    unit_by_question: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for unit in units:
        unit_by_question[str(unit["questionKey"])].append(unit)
    grouped: dict[str, dict[str, Any]] = {}
    for occurrence in occurrences:
        key = str(occurrence["questionKey"])
        if key not in grouped:
            page_number = int(occurrence.get("pageNumber") or 1)
            display_name = f"第 {occurrence['pathLabel']} 题"
            if show_page_number:
                display_name = f"第 {page_number} 页 · {display_name}"
            grouped[key] = {
                "questionKey": key,
                "displayName": display_name,
                "pageNumber": page_number,
                "path": occurrence["path"],
                "pathLabel": occurrence["pathLabel"],
                "content": occurrence["content"],
                "occurrences": [],
                "units": unit_by_question.get(key, []),
            }
        grouped[key]["occurrences"].append(occurrence)
    result = [
        question
        for question in grouped.values()
        if question["units"]
        or not all(occurrence.get("hasChildren") for occurrence in question["occurrences"])
    ]
    for question in result:
        review = apply_review_rules(question)
        question.update(review)
        question["stats"] = compute_stats(question["units"])
        question["unitIds"] = [unit["unitId"] for unit in question["units"]]
        question.pop("units", None)
    result.sort(key=lambda item: (item["pageNumber"], item["path"], item["questionKey"]))
    return result


def file_sha256(path: str | Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def stable_page_id(digest: str) -> str:
    return f"page-{digest[:16]}"


def stable_query_id(task_id: str, digest: str) -> str:
    return f"{task_id}-{digest[:16]}"


def load_roster_details(path: str | Path | None) -> dict[str, Any]:
    if not path:
        return {"byFile": {}, "students": []}
    roster_path = Path(path)
    if roster_path.suffix.lower() == ".json":
        raw = json.loads(roster_path.read_text(encoding="utf-8"))
        if isinstance(raw, list):
            rows = raw
        elif isinstance(raw, dict) and isinstance(raw.get("students"), list):
            rows = raw["students"]
        elif isinstance(raw, dict):
            rows = [
                {"file_name": file_name, **entry}
                for file_name, entry in raw.items()
                if isinstance(entry, dict)
            ]
        else:
            rows = []
    else:
        with roster_path.open("r", encoding="utf-8-sig", newline="") as handle:
            rows = list(csv.DictReader(handle))
    mapping: dict[str, dict[str, Any]] = {}
    students_by_key: dict[str, dict[str, str]] = {}
    for index, row in enumerate(rows, start=1):
        if not isinstance(row, dict):
            continue
        file_name = str(row.get("file_name") or row.get("fileName") or "").strip()
        raw_student_id = str(row.get("student_id") or row.get("studentId") or "").strip()
        raw_student_name = str(row.get("student_name") or row.get("studentName") or "").strip()
        if not file_name and not raw_student_id and not raw_student_name:
            continue
        student_key = raw_student_id or normalize_text(raw_student_name) or f"row-{index}"
        existing_student = students_by_key.get(student_key)
        student_id = existing_student["studentId"] if existing_student else raw_student_id or f"student-{index}"
        student_name = existing_student["studentName"] if existing_student else raw_student_name or f"学生 {index}"
        students_by_key[student_key] = {"studentId": student_id, "studentName": student_name}
        page_number_raw = row.get("page_number") or row.get("pageNumber") or 1
        try:
            page_number = int(page_number_raw)
        except (TypeError, ValueError):
            page_number = 1
        if file_name:
            mapping[file_name] = {
                "studentId": student_id,
                "studentName": student_name,
                "pageNumber": page_number,
            }
    return {"byFile": mapping, "students": list(students_by_key.values())}


def load_roster(path: str | Path | None) -> dict[str, dict[str, Any]]:
    return load_roster_details(path)["byFile"]


def compute_submission_stats(
    pages: Iterable[dict[str, Any]],
    roster_students: Iterable[dict[str, Any]],
    roster_provided: bool,
) -> dict[str, Any]:
    roster_ids = {str(student.get("studentId")) for student in roster_students if student.get("studentId")}
    submitted_ids = {
        str(page.get("studentId"))
        for page in pages
        if page.get("studentId") and str(page.get("studentId")) in roster_ids
    }
    total = len(roster_ids)
    submitted = len(submitted_ids)
    return {
        "rosterProvided": bool(roster_provided),
        "submittedStudentCount": submitted,
        "rosterStudentCount": total,
        "submissionRate": round(submitted / total * 100, 1) if total else None,
    }


def load_answers(path: str | Path | None) -> dict[str, Any]:
    if not path:
        return {}
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError("答案解析必须是以 questionKey 为键的 JSON 对象")
    return data


def load_page_order(path: str | Path | None, images: Iterable[str]) -> dict[str, dict[str, Any]]:
    """Load the image-inspected page order, independently of a class roster.

    Recognition is performed by the Skill on original images; this manifest
    records that evidence rather than pretending API array indices are page numbers.
    """
    if not path:
        return {}
    manifest = Path(path).resolve()
    rows = json.loads(manifest.read_text(encoding="utf-8"))
    if not isinstance(rows, list):
        raise ValueError("页序清单必须是 JSON 数组")
    expected = {str(Path(image).resolve()) for image in images}
    mapping: dict[str, dict[str, Any]] = {}
    for row in rows:
        if not isinstance(row, dict) or not row.get("sourcePath"):
            raise ValueError("每条页序记录必须包含 sourcePath")
        source = Path(row["sourcePath"])
        source = source if source.is_absolute() else manifest.parent / source
        key = str(source.resolve())
        number = row.get("pageNumber")
        if type(number) is not int or number < 1:
            raise ValueError("页序 pageNumber 必须是正整数")
        if not isinstance(row.get("evidence"), str) or not row["evidence"].strip():
            raise ValueError("页序记录必须保留图片页码或题目衔接依据 evidence")
        if key in mapping:
            raise ValueError("页序清单含重复图片路径")
        if bool(row.get("studentId")) != bool(row.get("studentName")):
            raise ValueError("页序中的学生标识与姓名必须同时提供")
        mapping[key] = row
    if set(mapping) != expected:
        raise ValueError("页序清单必须完整对应本次全部图片路径")
    return mapping


def call_correction(
    endpoint: str,
    query_id: str,
    image_bytes: bytes,
    retries: int = 2,
    timeout: int = 120,
    opener: Callable[..., Any] = urllib.request.urlopen,
    sleeper: Callable[[float], None] = time.sleep,
) -> dict[str, Any]:
    payload = json.dumps(
        {"queryId": query_id, "imageBase64": base64.b64encode(image_bytes).decode("ascii")}
    ).encode("utf-8")
    request = urllib.request.Request(
        endpoint,
        data=payload,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    for attempt in range(retries + 1):
        try:
            with opener(request, timeout=timeout) as response:
                result = json.loads(response.read().decode("utf-8"))
            if result.get("queryId") != query_id:
                raise RuntimeError("批改响应 queryId 与请求不一致")
            return result
        except urllib.error.HTTPError as error:
            if error.code == 400 or attempt >= retries:
                raise RuntimeError(f"批改请求失败（HTTP {error.code}）") from error
        except (urllib.error.URLError, TimeoutError, json.JSONDecodeError) as error:
            if attempt >= retries:
                raise RuntimeError("批改服务暂时不可用") from error
        sleeper(2**attempt)
    raise RuntimeError("批改服务暂时不可用")


def write_json_atomic(path: Path, data: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    temporary.replace(path)


def emit_progress(task_id: str, stage: str, **counts: Any) -> None:
    event = {"taskId": task_id, "stage": stage, **counts}
    print(json.dumps(event, ensure_ascii=False), file=sys.stderr, flush=True)


def _group_stats(items: Iterable[dict[str, Any]], key_name: str) -> list[dict[str, Any]]:
    buckets: dict[str, list[dict[str, Any]]] = defaultdict(list)
    labels: dict[str, str] = {}
    for item in items:
        key = str(item.get(key_name) or "unknown")
        buckets[key].append(item)
        label_key = "studentName" if key_name == "studentId" else "sourceName"
        labels[key] = str(item.get(label_key) or key)
    return [
        {key_name: key, "label": labels[key], "stats": compute_stats(bucket)}
        for key, bucket in sorted(buckets.items())
    ]


def align_question_keys(pages: list[dict[str, Any]], distance_limit: float = 40.0) -> None:
    """Align the same printed question across students by page, depth, and position.

    Correction responses may enumerate sibling answers in different orders, so API
    paths and OCR content are not reliable cross-student identifiers on their own.
    """
    pages_by_number: dict[int, list[dict[str, Any]]] = defaultdict(list)
    for page in pages:
        page_number = int(page.get("pageNumber") or 1)
        for occurrence in page.get("questionOccurrences") or []:
            occurrence["pageNumber"] = page_number
        for unit in page.get("reviewUnits") or []:
            unit["pageNumber"] = page_number
        pages_by_number[page_number].append(page)

    for page_number, same_number_pages in pages_by_number.items():
        student_ids = {str(page.get("studentId") or page.get("pageId")) for page in same_number_pages}
        if len(student_ids) < 2:
            continue
        anchors_by_depth: dict[int, list[dict[str, Any]]] = defaultdict(list)
        for page in same_number_pages:
            old_to_new: dict[str, str] = {}
            by_depth: dict[int, list[dict[str, Any]]] = defaultdict(list)
            for occurrence in page.get("questionOccurrences") or []:
                by_depth[len(occurrence.get("path") or [])].append(occurrence)
            for depth, occurrences in by_depth.items():
                anchors = anchors_by_depth[depth]
                candidates: list[tuple[float, int, int]] = []
                for occurrence_index, occurrence in enumerate(occurrences):
                    region = occurrence.get("region") or {}
                    for anchor_index, anchor in enumerate(anchors):
                        anchor_region = anchor["region"]
                        if region and anchor_region:
                            distance = math.hypot(
                                float(region.get("x", 0)) - float(anchor_region.get("x", 0)),
                                float(region.get("y", 0)) - float(anchor_region.get("y", 0)),
                            )
                            if distance <= distance_limit:
                                candidates.append((distance, occurrence_index, anchor_index))
                        elif occurrence.get("path") == anchor.get("path"):
                            candidates.append((0.0, occurrence_index, anchor_index))
                matched_occurrences: set[int] = set()
                matched_anchors: set[int] = set()
                for _, occurrence_index, anchor_index in sorted(candidates):
                    if occurrence_index in matched_occurrences or anchor_index in matched_anchors:
                        continue
                    occurrence = occurrences[occurrence_index]
                    old_to_new[str(occurrence["questionKey"])] = anchors[anchor_index]["questionKey"]
                    matched_occurrences.add(occurrence_index)
                    matched_anchors.add(anchor_index)
                for occurrence_index, occurrence in enumerate(occurrences):
                    if occurrence_index in matched_occurrences:
                        continue
                    key = _short_hash(
                        {"pageNumber": page_number, "depth": depth, "anchorIndex": len(anchors) + 1},
                        "question",
                    )
                    anchors.append(
                        {
                            "questionKey": key,
                            "region": occurrence.get("region") or {},
                            "path": occurrence.get("path") or [],
                        }
                    )
                    old_to_new[str(occurrence["questionKey"])] = key
                for occurrence in occurrences:
                    occurrence["questionKey"] = old_to_new[str(occurrence["questionKey"])]
            for unit in page.get("reviewUnits") or []:
                old_key = str(unit.get("questionKey"))
                if old_key in old_to_new:
                    unit["questionKey"] = old_to_new[old_key]


def assemble_task(metadata: dict[str, Any], pages: list[dict[str, Any]]) -> dict[str, Any]:
    # All consumers (student pages, question grouping and downloads) share this order.
    # Sort a copy: processing checkpoints must not reorder the upload loop's list.
    pages = sorted(pages, key=lambda page: (
        int(page.get("pageNumber") or 1),
        str(page.get("studentId") or ""),
        str(page.get("pageId") or ""),
    ))
    align_question_keys(pages)
    occurrences = [item for page in pages for item in page.get("questionOccurrences", [])]
    units = [item for page in pages for item in page.get("reviewUnits", [])]
    questions = group_questions(occurrences, units)
    mandatory = [question["questionKey"] for question in questions if question["reviewType"] == "mandatory"]
    suggested = [question["questionKey"] for question in questions if question["reviewType"] == "suggested"]
    statuses = {page.get("status") for page in pages if page.get("status") != "DUPLICATE"}
    if statuses and statuses <= {"COMPLETED", "EMPTY"}:
        task_status = "COMPLETED"
    elif "COMPLETED" in statuses or "EMPTY" in statuses:
        task_status = "PARTIAL"
    elif statuses:
        task_status = "FAILED"
    else:
        task_status = "FAILED"
    roster = metadata.get("roster") if isinstance(metadata.get("roster"), dict) else {}
    task = {
        **metadata,
        "updatedAt": utc_now(),
        "status": task_status,
        "pages": pages,
        "questions": questions,
        "reviewUnits": units,
        "reviewQueue": {"mandatory": mandatory, "suggested": suggested},
        "identicalAnswerGroups": group_identical_answers(
            [{**question, "units": [unit for unit in units if unit["questionKey"] == question["questionKey"]]} for question in questions]
        ),
        "stats": compute_stats(units),
        "studentStats": _group_stats(units, "studentId"),
        "pageStats": _group_stats(units, "pageId"),
        "submissionStats": compute_submission_stats(
            pages,
            roster.get("students") or [],
            bool(roster.get("provided")),
        ),
        "warnings": list(metadata.get("warnings") or []),
    }
    return task


def _load_fixture(response_dir: Path, source: Path, query_id: str) -> dict[str, Any]:
    candidates = [response_dir / f"{source.name}.json", response_dir / f"{source.stem}.json"]
    fixture = next((candidate for candidate in candidates if candidate.exists()), None)
    if fixture is None:
        raise FileNotFoundError(f"未找到 {source.name} 的离线响应")
    response = json.loads(fixture.read_text(encoding="utf-8"))
    response["queryId"] = query_id
    return response


def build_task(args: argparse.Namespace) -> dict[str, Any]:
    output = Path(args.output).resolve()
    manifest_path = output / "task.json"
    existing = json.loads(manifest_path.read_text(encoding="utf-8")) if manifest_path.exists() else {}
    task_id = args.task_id or existing.get("taskId") or f"correction-{uuid.uuid4().hex[:12]}"
    page_order = load_page_order(getattr(args, "page_order", None), args.images)
    if args.roster:
        roster_details = load_roster_details(args.roster)
        roster_info = {
            "provided": True,
            "students": roster_details["students"],
            "byFile": roster_details["byFile"],
        }
    else:
        existing_roster = existing.get("roster") if isinstance(existing.get("roster"), dict) else {}
        roster_info = {
            "provided": bool(existing_roster.get("provided")),
            "students": list(existing_roster.get("students") or []),
            "byFile": dict(existing_roster.get("byFile") or {}),
        }
    roster = roster_info["byFile"]
    answers = load_answers(args.answers)
    existing_pages = {page.get("pageId"): page for page in existing.get("pages", [])}
    accepted_hashes: set[str] = set()
    pages: list[dict[str, Any]] = []
    images_dir = output / "images"
    images_dir.mkdir(parents=True, exist_ok=True)
    metadata = {
        "schemaVersion": "1.0",
        "taskId": task_id,
        "createdAt": existing.get("createdAt") or utc_now(),
        "assignmentName": args.assignment_name or "未命名作业",
        "className": args.class_name or "",
        "tier": args.tier,
        "answers": answers,
        "roster": roster_info,
        "warnings": [],
    }

    emit_progress(task_id, "VALIDATING", selected=len(args.images))
    for index, image_value in enumerate(args.images, start=1):
        source = Path(image_value).resolve()
        if not source.is_file():
            pages.append(
                {
                    "pageId": f"missing-{index}",
                    "sourceName": source.name,
                    "status": "FAILED",
                    "error": "图片文件不存在或不可读取",
                    "questionOccurrences": [],
                    "reviewUnits": [],
                }
            )
            continue
        digest = file_sha256(source)
        page_id = stable_page_id(digest)
        cached = existing_pages.get(page_id)
        roster_entry = roster.get(source.name, {})
        order_entry = page_order.get(str(source), {})
        if order_entry.get("studentId") and roster_entry.get("studentId") and order_entry["studentId"] != roster_entry["studentId"]:
            raise ValueError(f"{source.name} 的页序学生标识与花名册不一致")
        previous = cached or {}
        student_id = roster_entry.get("studentId") or order_entry.get("studentId") or previous.get("studentId") or f"student-{digest[:12]}"
        student_name = roster_entry.get("studentName") or order_entry.get("studentName") or previous.get("studentName") or f"学生 {index}"
        page_number = int(order_entry.get("pageNumber") or roster_entry.get("pageNumber") or previous.get("pageNumber") or 1)
        page = {
            "pageId": page_id,
            "queryId": stable_query_id(task_id, digest),
            "sourceName": source.name,
            "sourcePath": str(source),
            "uploadIndex": previous.get("uploadIndex", index),
            "sha256": digest,
            "studentId": student_id,
            "studentName": student_name,
            "pageNumber": page_number,
            "pageOrderEvidence": order_entry.get("evidence") or previous.get("pageOrderEvidence") or "",
            "imagePath": f"images/{page_id}{source.suffix.lower()}",
        }
        if digest in accepted_hashes:
            page.update({"status": "DUPLICATE", "questionOccurrences": [], "reviewUnits": []})
            pages.append(page)
            continue
        accepted_hashes.add(digest)
        destination = output / page["imagePath"]
        if not destination.exists():
            shutil.copy2(source, destination)
        if cached and cached.get("status") in {"COMPLETED", "EMPTY"}:
            # Reorder cached results without rerunning correction or replacing unit IDs/history.
            restored = {**cached, **page}
            for collection in ("questionOccurrences", "reviewUnits"):
                for item in restored.get(collection) or []:
                    item.update({"pageNumber": page_number, "studentId": student_id})
                    if collection == "reviewUnits":
                        item.update({"studentName": student_name, "sourceName": source.name})
            pages.append(restored)
            continue
        emit_progress(task_id, "CORRECTING", current=index, total=len(args.images), file=source.name)
        try:
            if args.response_dir:
                response = _load_fixture(Path(args.response_dir), source, page["queryId"])
            else:
                response = call_correction(
                    ENDPOINTS[args.tier],
                    page["queryId"],
                    source.read_bytes(),
                    retries=args.retries,
                    timeout=args.timeout,
                )
            normalized = normalize_page(response, page, task_id)
            page.update(normalized)
            page["status"] = "COMPLETED" if normalized["questionOccurrences"] else "EMPTY"
        except Exception as error:  # keep the rest of a batch usable
            page.update(
                {
                    "status": "FAILED",
                    "error": str(error),
                    "questionOccurrences": [],
                    "reviewUnits": [],
                }
            )
        pages.append(page)
        snapshot = assemble_task(metadata, pages)
        write_json_atomic(manifest_path, snapshot)

    task = assemble_task(metadata, pages)
    write_json_atomic(manifest_path, task)
    emit_progress(
        task_id,
        "COMPLETED" if task["status"] == "COMPLETED" else task["status"],
        pages=len(pages),
        completed=sum(page.get("status") == "COMPLETED" for page in pages),
        failed=sum(page.get("status") == "FAILED" for page in pages),
    )
    return task


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="批量调用整页批改接口并生成可恢复任务数据")
    parser.add_argument("--images", nargs="+", required=True, help="学生作业图片路径")
    parser.add_argument("--output", required=True, help="任务输出目录")
    parser.add_argument("--tier", choices=sorted(ENDPOINTS), default="pro")
    parser.add_argument("--assignment-name", default="")
    parser.add_argument("--class-name", default="")
    parser.add_argument("--roster", help="CSV 或 JSON 学生名册")
    parser.add_argument("--page-order", help="查看原图后确定的页序 JSON（独立于花名册）")
    parser.add_argument("--answers", help="以 questionKey 为键的答案解析 JSON")
    parser.add_argument("--task-id", help="显式任务标识")
    parser.add_argument("--retries", type=int, default=2)
    parser.add_argument("--timeout", type=int, default=120)
    parser.add_argument("--response-dir", help=argparse.SUPPRESS)
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    build_task(args)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
