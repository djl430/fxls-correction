#!/usr/bin/env python3
"""Read the authoritative local teacher-review state without mutating it."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

from review_state import merge_task, read_state


def _read_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"{path.name} 必须是 JSON 对象")
    return value


def summary_snapshot(merged: dict[str, Any]) -> dict[str, Any]:
    return {
        "taskId": merged.get("taskId"),
        "assignmentName": merged.get("assignmentName"),
        "reviewStateRevision": merged.get("reviewStateRevision", 0),
        "reviewStateUpdatedAt": merged.get("reviewStateUpdatedAt"),
        "stats": merged.get("stats", {}),
        "studentStats": merged.get("studentStats", []),
        "questionStats": [
            {
                "questionKey": question.get("questionKey"),
                "displayName": question.get("displayName"),
                "stats": question.get("stats", {}),
            }
            for question in merged.get("questions", [])
        ],
        "reviewQueue": merged.get("reviewQueue", {"mandatory": [], "suggested": []}),
    }


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="读取老师改判后的最新本地批改结果")
    parser.add_argument("--task", required=True, type=Path, help="task.json 路径")
    parser.add_argument("--state", type=Path, help="可选的 review-state.json 路径")
    parser.add_argument("--summary", action="store_true", help="只输出身份、版本和统计摘要")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        task_path = args.task.resolve()
        task = _read_json(task_path)
        state = read_state(task_path, args.state)
        merged = merge_task(task, state)
        output = summary_snapshot(merged) if args.summary else merged
    except (OSError, UnicodeError, json.JSONDecodeError, ValueError) as error:
        print(f"无法读取最新批改结果：{error}", file=sys.stderr)
        return 2
    json.dump(output, sys.stdout, ensure_ascii=False, indent=2)
    sys.stdout.write("\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
