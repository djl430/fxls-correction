#!/usr/bin/env python3
"""Render a fixed offline review workspace from task.json."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path
from typing import Any

from review_state import initial_state, write_state_atomic


MARKER = "__TASK_JSON__"


def json_for_script(data: Any) -> str:
    return (
        json.dumps(data, ensure_ascii=False, separators=(",", ":"))
        .replace("&", "\\u0026")
        .replace("<", "\\u003c")
        .replace(">", "\\u003e")
        .replace("\u2028", "\\u2028")
        .replace("\u2029", "\\u2029")
    )


def render(task_path: str | Path, output_path: str | Path, template_path: str | Path | None = None) -> Path:
    task_file = Path(task_path).resolve()
    output_file = Path(output_path).resolve()
    if template_path is None:
        template_file = Path(__file__).resolve().parents[1] / "assets" / "review-template.html"
    else:
        template_file = Path(template_path).resolve()
    task = json.loads(task_file.read_text(encoding="utf-8"))
    template = template_file.read_text(encoding="utf-8")
    if template.count(MARKER) != 1:
        raise ValueError(f"模板必须且只能包含一个 {MARKER} 标记")
    rendered = template.replace(MARKER, json_for_script(task))
    rendered = rendered.replace('__REVIEW_LAYOUT__', (template_file.parent / 'review-layout.js').read_text(encoding='utf-8'))
    rendered = rendered.replace('__REVIEW_EXPORT__', (template_file.parent / 'review-export.js').read_text(encoding='utf-8'))
    output_file.parent.mkdir(parents=True, exist_ok=True)
    output_file.write_text(rendered, encoding="utf-8")
    mark_source = template_file.parent / "marks"
    mark_output = output_file.parent / "assets" / "marks"
    mark_output.mkdir(parents=True, exist_ok=True)
    for name in ("correct.png", "half-correct.png", "wrong.png"):
        shutil.copy2(mark_source / name, mark_output / name)
    state_file = output_file.parent / "review-state.json"
    if not state_file.exists():
        write_state_atomic(state_file, initial_state(task))
    return output_file


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="从 task.json 生成离线批改复核页面")
    parser.add_argument("--task", required=True, help="task.json 路径")
    parser.add_argument("--output", help="输出 HTML；默认与 task.json 同目录的 review.html")
    parser.add_argument("--template", help="自定义固定模板路径")
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    task_path = Path(args.task).resolve()
    output_path = Path(args.output).resolve() if args.output else task_path.parent / "review.html"
    result = render(task_path, output_path, args.template)
    print(result)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
