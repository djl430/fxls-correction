#!/usr/bin/env python3
"""Render a fixed offline review workspace from task.json."""

from __future__ import annotations

import argparse
import json
import shutil
import html
from pathlib import Path
from typing import Any

from review_state import initial_state, write_state_atomic


MARKER = "__TASK_JSON__"


def json_for_script(data: Any) -> str:
    return (
        json.dumps(data, ensure_ascii=False, separators=(",", ":"))
        .replace("&", "\\u0026")
        .replace("<", "\\u003c")
        .replace(">", "\\u003e")
        .replace("\u2028", "\\u2028")
        .replace("\u2029", "\\u2029")
    )


def render(task_path: str | Path, output_path: str | Path, template_path: str | Path | None = None) -> Path:
    task_file = Path(task_path).resolve()
    output_file = Path(output_path).resolve()
    if template_path is None:
        template_file = Path(__file__).resolve().parents[1] / "assets" / "review-template.html"
    else:
        template_file = Path(template_path).resolve()
    task = json.loads(task_file.read_text(encoding="utf-8"))
    template = template_file.read_text(encoding="utf-8")
    if template.count(MARKER) != 1:
        raise ValueError(f"模板必须且只能包含一个 {MARKER} 标记")
    rendered = template.replace(MARKER, json_for_script(task))
    rendered = rendered.replace('__REVIEW_THEME__', (template_file.parent / 'review-theme.css').read_text(encoding='utf-8'))
    rendered = rendered.replace('__REVIEW_LAYOUT__', (template_file.parent / 'review-layout.js').read_text(encoding='utf-8'))
    rendered = rendered.replace('__REVIEW_EXPORT__', (template_file.parent / 'review-export.js').read_text(encoding='utf-8'))
    output_file.parent.mkdir(parents=True, exist_ok=True)
    output_file.write_text(rendered, encoding="utf-8")
    mark_source = template_file.parent / "marks"
    mark_output = output_file.parent / "assets" / "marks"
    mark_output.mkdir(parents=True, exist_ok=True)
    for name in ("correct.png", "half-correct.png", "wrong.png"):
        shutil.copy2(mark_source / name, mark_output / name)
    shutil.copytree(template_file.parent / 'design', output_file.parent / 'assets' / 'design', dirs_exist_ok=True)
    state_file = output_file.parent / "review-state.json"
    if not state_file.exists():
        write_state_atomic(state_file, initial_state(task))
    render_result_card(task, output_file, template_file.parent)
    return output_file


def render_result_card(task: dict, review_file: Path, assets: Path) -> None:
    """Static host-card preview; runtime chat adapters use the same documented contract.

    Count current teacher overrides, never stale task.stats. Links carry the local
    server token forward only when the preview itself is served on that origin.
    """
    from review_state import validate_state
    state = validate_state(task, json.loads((review_file.parent / 'review-state.json').read_text(encoding='utf-8')))
    units = task.get('reviewUnits', [])
    statuses = [state.get('units', {}).get(u['unitId'], {}).get('finalStatus') or
                u.get('finalStatus') or u.get('originalStatus') or 'UNKNOWN' for u in units]
    statuses = ['FAILED' if s == 'UNDONE' else s for s in statuses]
    pending = sum(s not in ('PASS', 'HALF_PASS', 'FAILED') for s in statuses)
    keys = set(task.get('reviewQueue', {}).get('mandatory', []) + task.get('reviewQueue', {}).get('suggested', []))
    review_count = sum(u.get('questionKey') in keys for u in units)
    submission = task.get('submissionStats', {})
    students = {p.get('studentId') for p in task.get('pages', []) if p.get('studentId')}
    students.update(u.get('studentId') for u in units if u.get('studentId'))
    submitted = submission.get('submittedStudentCount', 0) if submission.get('rosterProvided') else len(students)
    roster = submission.get('rosterStudentCount', 0)
    people = f'{submitted}/{roster} 人' if submission.get('rosterProvided') else f'{submitted} 人' if students else '暂无法统计'
    rate = f'{statuses.count("PASS") / len(statuses):.1%}' if statuses else '暂无数据'
    reasons = list(dict.fromkeys(f'{q.get("displayName", q["questionKey"])}：{reason}'
                  for q in task.get('questions', []) if q['questionKey'] in keys
                  for reason in q.get('reviewReasons', [])))
    if review_count and not reasons:
        reasons.append(f'有 {review_count} 项作答建议复核，请在复核页查看。')
    if pending:
        reasons.insert(0, f'有 {pending} 项作答待批改，请在复核页查看。')
    reasons.extend(str(note) for note in task.get('materialNotes', []) if isinstance(note, str))
    if not units:
        reasons.insert(0, '暂未生成可复核作答，请补充包含完整题目和学生作答的清晰材料。')
    title = task.get('assignmentName') or '作业批改'
    values = {'TITLE': title, 'PEOPLE': people, 'PENDING': f'{pending} 项' if units else '暂无法统计',
              'REVIEW': f'{review_count} 项' if units else '暂无法统计', 'RATE': rate, 'URL': review_file.name}
    source = (assets / 'result-card-template.html').read_text(encoding='utf-8')
    for key, value in values.items():
        source = source.replace('__' + key + '__', html.escape(str(value), quote=True))
    source = source.replace('__REASONS__', ''.join(f'<li>{html.escape(r)}</li>' for r in reasons) or '<li>暂无需要处理或建议复核的事项。</li>')
    if not units:
        import re
        source = re.sub(r'<a id="review-link".*?</a>', '<span>暂未生成可复核作答</span>', source)
    (review_file.parent / 'result-card.html').write_text(source, encoding='utf-8')


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="从 task.json 生成离线批改复核页面")
    parser.add_argument("--task", required=True, help="task.json 路径")
    parser.add_argument("--output", help="输出 HTML；默认与 task.json 同目录的 review.html")
    parser.add_argument("--template", help="自定义固定模板路径")
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    task_path = Path(args.task).resolve()
    output_path = Path(args.output).resolve() if args.output else task_path.parent / "review.html"
    result = render(task_path, output_path, args.template)
    print(result)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
