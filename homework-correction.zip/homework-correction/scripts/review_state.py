#!/usr/bin/env python3
"""Validate, persist, and merge teacher review state for a correction task."""

from __future__ import annotations

import copy
import json
import os
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


SCHEMA_VERSION = "1.0"
VALID_FINAL_STATUSES = {
    "PASS",
    "HALF_PASS",
    "FAILED",
    "UNABLE_TO_CHECK",
    "UNSUPPORTED",
    "UNKNOWN",
}
KNOWN_STATUSES = VALID_FINAL_STATUSES | {"UNDONE"}


def initial_state(task: dict[str, Any]) -> dict[str, Any]:
    task_id = task.get("taskId")
    if not isinstance(task_id, str) or not task_id:
        raise ValueError("task.json 缺少有效 taskId")
    return {
        "schemaVersion": SCHEMA_VERSION,
        "taskId": task_id,
        "revision": 0,
        "updatedAt": None,
        "units": {},
    }


def _validate_history(history: Any) -> list[dict[str, Any]]:
    if not isinstance(history, list):
        raise ValueError("history 必须是数组")
    result: list[dict[str, Any]] = []
    for entry in history:
        if not isinstance(entry, dict):
            raise ValueError("history 元素必须是对象")
        before, after = entry.get("from"), entry.get("to")
        if before not in KNOWN_STATUSES or after not in VALID_FINAL_STATUSES:
            raise ValueError("history 包含非法状态")
        changed_at = entry.get("changedAt")
        source = entry.get("source")
        if not isinstance(changed_at, str) or not changed_at:
            raise ValueError("history 缺少 changedAt")
        if not isinstance(source, str) or not source:
            raise ValueError("history 缺少 source")
        result.append({"from": before, "to": after, "changedAt": changed_at, "source": source})
    return result


def validate_state(
    task: dict[str, Any],
    candidate: dict[str, Any],
    *,
    current_revision: int | None = None,
) -> dict[str, Any]:
    if not isinstance(candidate, dict):
        raise ValueError("review-state.json 必须是对象")
    if candidate.get("schemaVersion") != SCHEMA_VERSION:
        raise ValueError("不支持的 review-state schemaVersion")
    if candidate.get("taskId") != task.get("taskId"):
        raise ValueError("review-state 与 task.json 不属于同一任务")
    revision = candidate.get("revision")
    if isinstance(revision, bool) or not isinstance(revision, int) or revision < 0:
        raise ValueError("revision 必须是非负整数")
    if current_revision is not None and revision < current_revision:
        raise ValueError("review-state revision 早于当前文件")
    updated_at = candidate.get("updatedAt")
    if updated_at is not None and (not isinstance(updated_at, str) or not updated_at):
        raise ValueError("updatedAt 必须是时间字符串或 null")
    units = candidate.get("units")
    if not isinstance(units, dict):
        raise ValueError("units 必须是对象")
    valid_unit_ids = {unit.get("unitId") for unit in task.get("reviewUnits", []) if unit.get("unitId")}
    clean_units: dict[str, dict[str, Any]] = {}
    for unit_id, value in units.items():
        if unit_id not in valid_unit_ids:
            raise ValueError(f"review-state 包含未知 unitId: {unit_id}")
        if not isinstance(value, dict):
            raise ValueError(f"{unit_id} 的状态必须是对象")
        status = value.get("finalStatus")
        if status not in VALID_FINAL_STATUSES:
            raise ValueError(f"{unit_id} 包含非法 finalStatus")
        clean_units[unit_id] = {
            "finalStatus": status,
            "history": _validate_history(value.get("history", [])),
        }
    return {
        "schemaVersion": SCHEMA_VERSION,
        "taskId": candidate["taskId"],
        "revision": revision,
        "updatedAt": updated_at,
        "units": clean_units,
    }


def read_state(task_path: str | Path, state_path: str | Path | None = None) -> dict[str, Any]:
    task_file = Path(task_path).resolve()
    task = json.loads(task_file.read_text(encoding="utf-8"))
    state_file = Path(state_path).resolve() if state_path else task_file.parent / "review-state.json"
    if not state_file.exists():
        return initial_state(task)
    candidate = json.loads(state_file.read_text(encoding="utf-8"))
    return validate_state(task, candidate)


def write_state_atomic(path: str | Path, state: dict[str, Any]) -> None:
    destination = Path(path).resolve()
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary_name: str | None = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w",
            encoding="utf-8",
            dir=destination.parent,
            prefix=f".{destination.name}.",
            suffix=".tmp",
            delete=False,
        ) as handle:
            temporary_name = handle.name
            json.dump(state, handle, ensure_ascii=False, indent=2)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary_name, destination)
        temporary_name = None
    finally:
        if temporary_name:
            try:
                Path(temporary_name).unlink()
            except FileNotFoundError:
                pass


def calculate_stats(units: list[dict[str, Any]]) -> dict[str, Any]:
    counts = {status: 0 for status in KNOWN_STATUSES}
    undone = 0
    for unit in units:
        if unit.get("originalStatus") == "UNDONE":
            undone += 1
        status = unit.get("finalStatus") or unit.get("originalStatus") or "UNKNOWN"
        if status == "UNDONE":
            status = "FAILED"
        if status not in counts:
            status = "UNKNOWN"
        counts[status] += 1
    total = len(units)
    completed = counts["PASS"] + counts["HALF_PASS"] + counts["FAILED"]
    return {
        "total": total,
        "completed": completed,
        "unfinished": total - completed,
        "correct": counts["PASS"],
        "halfCorrect": counts["HALF_PASS"],
        "incorrect": counts["FAILED"],
        "undone": undone,
        "unableToCheck": counts["UNABLE_TO_CHECK"],
        "unsupported": counts["UNSUPPORTED"],
        "unknown": counts["UNKNOWN"],
        "correctRate": round(counts["PASS"] / total * 100, 1) if total else None,
        "completionRate": round(completed / total * 100, 1) if total else None,
    }


def merge_task(task: dict[str, Any], state: dict[str, Any]) -> dict[str, Any]:
    clean_state = validate_state(task, state)
    merged = copy.deepcopy(task)
    changes = clean_state["units"]
    for unit in merged.get("reviewUnits", []):
        saved = changes.get(unit.get("unitId"))
        if saved:
            unit["finalStatus"] = saved["finalStatus"]
            unit["history"] = copy.deepcopy(saved["history"])
        elif unit.get("finalStatus") == "UNDONE" or (
            not unit.get("finalStatus") and unit.get("originalStatus") == "UNDONE"
        ):
            unit["finalStatus"] = "FAILED"

    all_units = merged.get("reviewUnits", [])
    merged["stats"] = calculate_stats(all_units)
    for question in merged.get("questions", []):
        question_units = [unit for unit in all_units if unit.get("questionKey") == question.get("questionKey")]
        question["stats"] = calculate_stats(question_units)

    students: dict[str, dict[str, Any]] = {}
    order: list[str] = []
    for unit in all_units:
        student_id = unit.get("studentId") or f"page:{unit.get('pageId', 'unknown')}"
        if student_id not in students:
            order.append(student_id)
            students[student_id] = {
                "studentId": student_id,
                "label": unit.get("studentName") or unit.get("sourceName") or "未命名学生",
                "units": [],
            }
        students[student_id]["units"].append(unit)
    merged["studentStats"] = [
        {"studentId": student_id, "label": students[student_id]["label"], "stats": calculate_stats(students[student_id]["units"])}
        for student_id in order
    ]
    merged["reviewStateRevision"] = clean_state["revision"]
    merged["reviewStateUpdatedAt"] = clean_state["updatedAt"]
    return merged


def next_state(task: dict[str, Any], candidate: dict[str, Any], current_revision: int) -> dict[str, Any]:
    clean = validate_state(task, candidate)
    clean["revision"] = current_revision + 1
    clean["updatedAt"] = datetime.now(timezone.utc).isoformat()
    return clean
