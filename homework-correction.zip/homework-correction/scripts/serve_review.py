#!/usr/bin/env python3
"""Serve one review workspace and persist teacher changes on loopback only."""

from __future__ import annotations

import argparse
import json
import mimetypes
import secrets
import threading
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, quote, urlsplit

from review_state import initial_state, next_state, validate_state, write_state_atomic


MAX_BODY_BYTES = 2 * 1024 * 1024
LOOPBACK_HOSTS = {"127.0.0.1", "localhost", "::1"}


def _host_name(value: str) -> str:
    if value.startswith("["):
        return value[1:].split("]", 1)[0]
    return value.split(":", 1)[0]


class ReviewServer(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(self, address, handler, *, task_path: Path, task: dict[str, Any], token: str):
        super().__init__(address, handler)
        self.task_path = task_path
        self.task_dir = task_path.parent
        self.task = task
        self.state_path = self.task_dir / "review-state.json"
        self.review_token = token
        self.state_lock = threading.Lock()

    @property
    def review_url(self) -> str:
        host, port = self.server_address[:2]
        shown_host = "127.0.0.1" if host in {"0.0.0.0", "::"} else host
        return f"http://{shown_host}:{port}/review.html?token={quote(self.review_token)}"


class ReviewHandler(BaseHTTPRequestHandler):
    server: ReviewServer

    def log_message(self, format: str, *args: Any) -> None:
        return

    def _valid_host(self) -> bool:
        host = self.headers.get("Host", "")
        return _host_name(host) in LOOPBACK_HOSTS

    def _valid_origin(self) -> bool:
        origin = self.headers.get("Origin")
        if not origin:
            return True
        parsed = urlsplit(origin)
        return parsed.scheme == "http" and (parsed.hostname or "") in LOOPBACK_HOSTS and parsed.port == self.server.server_address[1]

    def _token(self) -> str:
        header = self.headers.get("X-Review-Token", "")
        if header:
            return header
        query = parse_qs(urlsplit(self.path).query)
        return (query.get("token") or [""])[0]

    def _json(self, status: int, payload: dict[str, Any]) -> None:
        body = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(body)

    def _error(self, status: int, message: str) -> None:
        self._json(status, {"error": message})

    def _authorized_api(self) -> bool:
        if not self._valid_host() or not self._valid_origin():
            self._error(HTTPStatus.FORBIDDEN, "请求来源不被允许")
            return False
        if not secrets.compare_digest(self._token(), self.server.review_token):
            self._error(HTTPStatus.FORBIDDEN, "任务令牌无效")
            return False
        return True

    def do_GET(self) -> None:
        path = urlsplit(self.path).path
        if path == "/api/review-state":
            if not self._authorized_api():
                return
            try:
                with self.server.state_lock:
                    candidate = json.loads(self.server.state_path.read_text(encoding="utf-8"))
                    state = validate_state(self.server.task, candidate)
                self._json(HTTPStatus.OK, state)
            except (OSError, json.JSONDecodeError, ValueError):
                self._error(HTTPStatus.INTERNAL_SERVER_ERROR, "本地状态文件无法读取")
            return
        self._serve_file(path)

    def _serve_file(self, path: str) -> None:
        if not self._valid_host():
            self._error(HTTPStatus.FORBIDDEN, "请求来源不被允许")
            return
        if path in {"", "/"}:
            path = "/review.html"
        if path in {"/review.html", "/result-card.html"}:
            relative = Path(path.lstrip("/"))
        elif path.startswith("/assets/") or path.startswith("/images/"):
            relative = Path(path.lstrip("/"))
        else:
            self._error(HTTPStatus.NOT_FOUND, "文件不存在")
            return
        target = (self.server.task_dir / relative).resolve()
        try:
            target.relative_to(self.server.task_dir)
        except ValueError:
            self._error(HTTPStatus.NOT_FOUND, "文件不存在")
            return
        if not target.is_file():
            self._error(HTTPStatus.NOT_FOUND, "文件不存在")
            return
        body = target.read_bytes()
        content_type = mimetypes.guess_type(target.name)[0] or "application/octet-stream"
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", f"{content_type}; charset=utf-8" if content_type.startswith("text/") else content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.end_headers()
        self.wfile.write(body)

    def do_PUT(self) -> None:
        if urlsplit(self.path).path != "/api/review-state":
            self._error(HTTPStatus.NOT_FOUND, "接口不存在")
            return
        if not self._authorized_api():
            return
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            self._error(HTTPStatus.BAD_REQUEST, "请求长度无效")
            return
        if length <= 0 or length > MAX_BODY_BYTES:
            self._error(HTTPStatus.BAD_REQUEST, "请求内容为空或过大")
            return
        try:
            payload = json.loads(self.rfile.read(length).decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            self._error(HTTPStatus.BAD_REQUEST, "请求不是有效 JSON")
            return
        if not isinstance(payload, dict) or payload.get("taskId") != self.server.task.get("taskId"):
            self._error(HTTPStatus.BAD_REQUEST, "任务不匹配")
            return
        base_revision = payload.get("baseRevision")
        if isinstance(base_revision, bool) or not isinstance(base_revision, int) or base_revision < 0:
            self._error(HTTPStatus.BAD_REQUEST, "baseRevision 无效")
            return
        try:
            with self.server.state_lock:
                current = validate_state(
                    self.server.task,
                    json.loads(self.server.state_path.read_text(encoding="utf-8")),
                )
                if base_revision != current["revision"]:
                    self._error(HTTPStatus.CONFLICT, "本地状态已有更新，请重新加载")
                    return
                candidate = {
                    "schemaVersion": "1.0",
                    "taskId": payload["taskId"],
                    "revision": current["revision"],
                    "updatedAt": current["updatedAt"],
                    "units": payload.get("units"),
                }
                saved = next_state(self.server.task, candidate, current["revision"])
                write_state_atomic(self.server.state_path, saved)
            self._json(HTTPStatus.OK, saved)
        except (OSError, json.JSONDecodeError, ValueError) as error:
            self._error(HTTPStatus.BAD_REQUEST, str(error))


def create_server(
    task_path: str | Path,
    host: str = "127.0.0.1",
    port: int = 0,
    token: str | None = None,
) -> ReviewServer:
    if host not in LOOPBACK_HOSTS:
        raise ValueError("复核服务只能监听本机回环地址")
    task_file = Path(task_path).resolve()
    task = json.loads(task_file.read_text(encoding="utf-8"))
    state_path = task_file.parent / "review-state.json"
    if state_path.exists():
        validate_state(task, json.loads(state_path.read_text(encoding="utf-8")))
    else:
        write_state_atomic(state_path, initial_state(task))
    return ReviewServer((host, port), ReviewHandler, task_path=task_file, task=task, token=token or secrets.token_urlsafe(24))


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="在本机打开可持续写入改判结果的复核页面")
    parser.add_argument("--task", required=True, help="task.json 路径")
    parser.add_argument("--host", default="127.0.0.1", help="仅允许本机回环地址")
    parser.add_argument("--port", type=int, default=0, help="监听端口；0 表示自动选择")
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    server = create_server(args.task, args.host, args.port)
    print(json.dumps({"taskId": server.task.get("taskId"), "stage": "REVIEW_READY", "url": server.review_url}, ensure_ascii=False), flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
